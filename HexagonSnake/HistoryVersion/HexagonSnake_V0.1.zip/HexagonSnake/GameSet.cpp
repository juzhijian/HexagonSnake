#include "GameSet.h"

GameSet::GameSet(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

GameSet::~GameSet()
{

}
