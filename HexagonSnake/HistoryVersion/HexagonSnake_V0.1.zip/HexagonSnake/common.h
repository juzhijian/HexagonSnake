#ifndef _COMMON_H_
#define _COMMON_H_

//***** INCLUDE *****//
#include <qglobal.h>
#include <QDebug>


//***** DEFINE *****//
#define		PRO_NAME				"HexagonSnake"
#define		PRO_VER					"1.0"

#define		SNAKE_MAP_WIDTH			800
#define		SNAKE_MAP_HEIGHT		600

#endif // !_COMMON_H
