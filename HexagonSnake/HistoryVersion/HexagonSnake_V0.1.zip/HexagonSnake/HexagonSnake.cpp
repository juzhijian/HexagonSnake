#include "HexagonSnake.h"

HexagonSnake::HexagonSnake(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	// windows setting
	//this->setMinimumSize(800, 600);
	this->resize(800, 600);
	strProPath = QApplication::applicationDirPath();

	// program setting
	loadDefaultSettings();
	/*
	if (!loadSettings())
	{
	loadDefaultSettings();
	}
	*/

	// ctrl setiing
	createCtrl();

	initMapAndSnake();

}

HexagonSnake::~HexagonSnake()
{

}


void HexagonSnake::createCtrl()
{
	// exit key label

	// pause key label
	bPuase = false;
	pLabelExit = new QLabel(tr("Pause"), this);
	pLabelExit->setGeometry(this->geometry());
	pLabelExit->hide();
}

bool HexagonSnake::loadSettings()
{
	QSettings	s("settings.ini", QSettings::IniFormat);
	s.setIniCodec("utf-8");

	keyMoveUp = Qt::Key(s.value("KeyBoard/moveUp").toInt());
	keyMoveDown = Qt::Key(s.value("KeyBoard/moveDown").toInt());
	keyMoveLeftup = Qt::Key(s.value("KeyBoard/moveLeftup").toInt());
	keyMoveLeftdown = Qt::Key(s.value("KeyBoard/moveLeftdown").toInt());
	keyMoveRightup = Qt::Key(s.value("KeyBoard/moveRightup").toInt());
	keyMoveRightdown = Qt::Key(s.value("KeyBoard/moveRightdown").toInt());
	keyStart = Qt::Key(s.value("KeyBoard/start").toInt());
	keyExit = Qt::Key(s.value("KeyBoard/exit").toInt());

	return true;
}

void HexagonSnake::loadDefaultSettings()
{
	// snake and map
	nSideSize = 30;
	nMapW = SNAKE_MAP_WIDTH;
	nMapH = SNAKE_MAP_HEIGHT;

	// key
	keyMoveUp = Qt::Key_E;
	keyMoveDown = Qt::Key_D;
	keyMoveLeftup = Qt::Key_W;
	keyMoveLeftdown = Qt::Key_S;
	keyMoveRightup = Qt::Key_R;
	keyMoveRightdown = Qt::Key_F;
	mapKey2Int.insert(keyMoveUp, 0);
	mapKey2Int.insert(keyMoveDown, 1);
	mapKey2Int.insert(keyMoveLeftup, 2);
	mapKey2Int.insert(keyMoveLeftdown, 3);
	mapKey2Int.insert(keyMoveRightup, 4);
	mapKey2Int.insert(keyMoveRightdown, 5);

	keyStart = Qt::Key_Return;
	keyExit = Qt::Key_Space;

#if(1)
	QSettings setting("settings.ini", QSettings::IniFormat);
	setting.setIniCodec("utf-8");

	setting.beginGroup("SnakeAndMap");
	setting.setValue("sideSize", nSideSize);
	setting.setValue("mapWidth", nMapW);
	setting.setValue("mapHeight", nMapH);
	setting.endGroup();

	setting.beginGroup("KeyBoard");
	setting.setValue("moveUp", keyMoveUp);
	setting.setValue("moveDown", keyMoveDown);
	setting.setValue("moveLeftup", keyMoveLeftup);
	setting.setValue("moveLeftdown", keyMoveLeftdown);
	setting.setValue("moveRightup", keyMoveRightup);
	setting.setValue("moveRightdown", keyMoveRightdown);
	setting.setValue("start", keyStart);
	setting.setValue("exit", keyExit);
	setting.endGroup();

#endif

}

void HexagonSnake::changeSettings()
{
	GameSet	set(this);
	if (QDialog::Accepted == set.exec())
	{

	}
	else
	{

	}

}

void HexagonSnake::initMapAndSnake()
{
	// create showing image area
	pMapImg = new QImage(nMapW, nMapH, QImage::Format_ARGB32_Premultiplied);

	// create the Smap instance
	mapRect.setLeft(20);
	mapRect.setTop(20);
	mapRect.setWidth(760);
	mapRect.setHeight(560);
	pSmap = new Smap(mapRect,nSideSize,this);

	// create the Snake instance
	pSnake = new Snake(mapRect,nSideSize, pSmap->getLeftupPoint(), this);
	keyCurDir = keyMoveDown;
	
	connect(pSnake, &Snake::foodGetted, 
		[=]{
		delete pFoodHg;
		createNewFood();
	});

	// create the food
	nFoodAllNum = pSmap->getHgPointNum();
	penFood.setColor(Qt::yellow);
	penFood.setWidth(2);
	brushStyle = QRadialGradient();
	brushStyle.setColorAt(0, Qt::yellow);
	brushStyle.setColorAt(1, Qt::darkMagenta);
	brushStyle.setSpread(QGradient::ReflectSpread);
	createNewFood();

	// draw the map and snake
	drawMapAndSnake();

	// set the timer event
	mapTimerInt = 350;
	mapTimerId = QObject::startTimer(mapTimerInt);
}

void HexagonSnake::drawMapAndSnake()
{
	pMapImg->fill(QColor(0, 0, 0));

	QPainter pp(pMapImg);
	
	// draw map
	pp.drawImage(mapRect.left(),mapRect.top(), pSmap->getMap());

	// draw snake
	pSnake->moveNext(mapKey2Int.value(keyCurDir),pointFoodHg);
	pp.drawImage(mapRect.left(), mapRect.top(), pSnake->getSnake());

	// draw food
	pp.setPen(penFood);
	pp.setBrush(brushStyle);
	pp.drawConvexPolygon(*pFoodHg);
}

void HexagonSnake::createNewFood()
{
	qsrand(QTime::currentTime().minute()+QTime::currentTime().second()*1000);
	int index = qrand() % nFoodAllNum;
			// get the num between [a,b): (qrand() % (b-a)) + a

	pFoodHg = new Hexagon(nSideSize);
	pFoodHg->initHexagon();
	pointFoodHg = pSmap->getVecHgPoint(index);
	pFoodHg->move(QPoint(mapRect.left(),mapRect.top()) + pointFoodHg);
}

/*******************************************************************/

void HexagonSnake::paintEvent(QPaintEvent *e)
{
	QPainter painter(this);
	//painter.setViewport(0, 0, 800, 600);			
	// ʵ����ʾ���򣬼��������꣺��painter���Ƶ�����Ĭ��Ϊthis->geometry()�����洰�ڵĸı���ı�
	//painter.setWindow(0, 0, 300, 200);				
	// ��ͼ���򣬼��߼����꣺���� 800x600 ����ʾ����ӳ��� 300x200 ��ͼ����
	//painter.fillRect(0, 0, 150, 100, Qt::green);
	// ����һ������ͼ���򡱵�1/4��С�ľ��Σ����ı䴰�ڴ�С��������Ϊ���ڴ�С��1/4
	painter.setWindow(0, 0, this->nMapW, this->nMapH);
	painter.drawImage(0, 0, *pMapImg);
}

void HexagonSnake::timerEvent(QTimerEvent *e)
{
	drawMapAndSnake();
	update();
}

void HexagonSnake::keyPressEvent(QKeyEvent *e)
{
	int key = e->key();
	if (keyMoveUp == key
		|| keyMoveDown == key
		|| keyMoveLeftup == key
		|| keyMoveLeftdown == key
		|| keyMoveRightup == key
		|| keyMoveRightdown == key)
	{
		keyCurDir = Qt::Key(key);
	}

	if (keyStart == key)
	{
		qDebug() << "start";
	}
	else if (keyExit == key)
	{
		if (bPuase)
		{
			mapTimerId = QObject::startTimer(mapTimerInt);
			pLabelExit->hide();
		}
		else
		{
			QObject::killTimer(mapTimerId);
			pLabelExit->show();
		}
		bPuase = !bPuase;
	}
	else if (Qt::Key_O == key)
	{
		this->changeSettings();
	}
}

void HexagonSnake::keyReleaseEvent(QKeyEvent *e)
{

}